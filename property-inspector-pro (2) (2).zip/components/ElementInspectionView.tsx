import React, { useState, useEffect } from 'react';
import { InspectionElement, Photo, WorkStatus } from '../types';
import { WORK_STATUSES, ELEMENT_CHECKLISTS } from '../utils/checklistData';
import { getElementIconComponent } from '../utils/iconUtils';
import PhotoUploader from './PhotoUploader';
import VoiceInput from './VoiceInput';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';

interface ElementInspectionViewProps {
  floorId: string;
  roomId: string;
  elementId: string;
  getElement: (floorId: string, roomId: string, elementId: string) => InspectionElement | undefined;
  updateElement: (floorId: string, roomId: string, elementId: string, updatedElement: Partial<InspectionElement>) => void;
  onClose: () => void;
}

const ElementInspectionView: React.FC<ElementInspectionViewProps> = ({
  floorId,
  roomId,
  elementId,
  getElement,
  updateElement,
  onClose,
}) => {
  const [element, setElement] = useState<InspectionElement | null>(null);

  useEffect(() => {
    const fetchedElement = getElement(floorId, roomId, elementId);
    if (fetchedElement) {
      setElement(fetchedElement);
    } else {
        // If element is not found (e.g., after deletion), close the view
        onClose();
    }
  }, [floorId, roomId, elementId, getElement, onClose]);
  
  const handleUpdate = (updates: Partial<InspectionElement>) => {
      if (element) {
          const updatedElement = { ...element, ...updates };
          setElement(updatedElement);
          updateElement(floorId, roomId, elementId, updates);
      }
  };
  
  const handleProblemToggle = (problem: string) => {
      if (element) {
          const newProblems = element.problems.includes(problem)
            ? element.problems.filter(p => p !== problem)
            : [...element.problems, problem];
          handleUpdate({ problems: newProblems });
      }
  }

  if (!element) {
    return (
       <div className="text-center p-10">
            <h2 className="text-xl font-semibold text-brand-gray-700">Element not found.</h2>
            <p className="text-brand-gray-500">It might have been deleted. Returning to the project view.</p>
        </div>
    );
  }
  
  const ElementIcon = getElementIconComponent(element.elementType);
  const problemOptions = ELEMENT_CHECKLISTS[element.elementType] || [];

  return (
    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/50">
      <div className="flex items-center gap-4 mb-6">
        <button onClick={onClose} className="p-2 rounded-full hover:bg-brand-gray-100 transition-colors">
            <ArrowLeftIcon />
        </button>
        <h2 className="text-2xl font-bold text-brand-gray-900 flex items-center gap-3">
            Inspecting: 
            <span className="text-brand-blue flex items-center gap-2">
                {ElementIcon && <ElementIcon className="w-6 h-6" />}
                {element.elementType}
            </span>
        </h2>
      </div>

      <div className="space-y-6">
        {/* Status of Work */}
        <div>
          <label className="block text-sm font-medium text-brand-gray-700 mb-1">Status of Work</label>
          <select
            value={element.workStatus}
            onChange={(e) => handleUpdate({ workStatus: e.target.value as WorkStatus })}
            className="w-full md:w-1/3 px-4 py-2 bg-white/80 border border-brand-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-orange focus:border-brand-blue transition"
          >
            {WORK_STATUSES.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>

        {/* Problem Checklist */}
        {problemOptions.length > 0 && (
            <div>
                <label className="block text-sm font-medium text-brand-gray-700 mb-2">Problem Checklist</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {problemOptions.map(problem => (
                        <label key={problem} className="flex items-center p-3 border rounded-lg has-[:checked]:bg-blue-50 has-[:checked]:border-brand-blue cursor-pointer transition-colors shadow-sm">
                            <input
                                type="checkbox"
                                checked={element.problems.includes(problem)}
                                onChange={() => handleProblemToggle(problem)}
                                className="h-4 w-4 rounded border-gray-300 text-brand-blue focus:ring-brand-blue"
                            />
                            <span className="ml-3 text-sm text-brand-gray-700">{problem}</span>
                        </label>
                    ))}
                </div>
            </div>
        )}

        {/* Remarks */}
        <div className="relative">
            <label className="block text-sm font-medium text-brand-gray-700 mb-1">Remarks</label>
            <textarea
                value={element.notes}
                onChange={(e) => handleUpdate({ notes: e.target.value })}
                rows={4}
                placeholder="Add inspection notes here, or use the microphone to dictate..."
                className="w-full p-2 pr-10 text-sm bg-white/80 border border-brand-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-orange focus:border-brand-blue transition"
            />
            <VoiceInput
                onTranscript={(transcript) => handleUpdate({ notes: element.notes ? `${element.notes} ${transcript}` : transcript })}
            />
        </div>

        {/* Photo Upload */}
        <PhotoUploader 
            photos={element.photos}
            onUpdatePhotos={(photos: Photo[]) => handleUpdate({ photos })}
        />

        {/* Finalize Button */}
        <div className="pt-6 border-t border-white/50">
            <button
                onClick={onClose}
                className="w-full md:w-auto px-8 py-3 border border-transparent shadow-lg text-base font-bold rounded-lg text-white bg-brand-blue hover:shadow-xl transition-shadow focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue"
            >
                Save and Return
            </button>
        </div>
      </div>
    </div>
  );
};

export default ElementInspectionView;