import React, { useRef, useEffect, useState } from 'react';
import { Photo } from '../types';

interface PhotoEditorProps {
    photo: Photo;
    onSave: (photoId: string, markingsDataUrl: string) => void;
    onClose: () => void;
}

const PhotoEditor: React.FC<PhotoEditorProps> = ({ photo, onSave, onClose }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [color, setColor] = useState('#FF0000'); // Default to red
    const [lineWidth, setLineWidth] = useState(5);

    const getCoords = (e: React.MouseEvent | React.TouchEvent): {x: number, y: number} => {
        const canvas = canvasRef.current;
        if (!canvas) return { x: 0, y: 0 };
        const rect = canvas.getBoundingClientRect();
        if ('touches' in e.nativeEvent) {
             return {
                x: e.nativeEvent.touches[0].clientX - rect.left,
                y: e.nativeEvent.touches[0].clientY - rect.top
            };
        }
        return {
            x: e.nativeEvent.offsetX,
            y: e.nativeEvent.offsetY,
        }
    }
    
    useEffect(() => {
        const canvas = canvasRef.current;
        const image = new Image();
        image.src = photo.dataUrl;
        image.onload = () => {
            if (canvas) {
                // Set canvas size to image's natural dimensions for high-res drawing
                canvas.width = image.naturalWidth;
                canvas.height = image.naturalHeight;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    // If existing markings, draw them
                    if (photo.markings) {
                        const markingsImage = new Image();
                        markingsImage.src = photo.markings;
                        markingsImage.onload = () => {
                            ctx.drawImage(markingsImage, 0, 0);
                        }
                    }
                }
            }
        };
    }, [photo.dataUrl, photo.markings]);
    
    const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx) return;

        setIsDrawing(true);
        const {x, y} = getCoords(e);
        ctx.beginPath();
        ctx.moveTo(x * (canvas.width / canvas.offsetWidth), y * (canvas.height / canvas.offsetHeight)); // Scale to canvas resolution
    };

    const draw = (e: React.MouseEvent | React.TouchEvent) => {
        if (!isDrawing) return;
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx) return;
        
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        const {x, y} = getCoords(e);
        ctx.lineTo(x * (canvas.width / canvas.offsetWidth), y * (canvas.height / canvas.offsetHeight)); // Scale
        ctx.stroke();
    };

    const stopDrawing = () => {
        setIsDrawing(false);
    };



    const handleSave = () => {
        const canvas = canvasRef.current;
        if (canvas) {
            onSave(photo.id, canvas.toDataURL()); // Save as PNG
        }
    };
    
    const clearCanvas = () => {
        const canvas = canvasRef.current;
        if (canvas) {
            const ctx = canvas.getContext('2d');
            ctx?.clearRect(0, 0, canvas.width, canvas.height);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-full flex flex-col">
                <div className="p-4 border-b flex justify-between items-center">
                    <h3 className="text-lg font-medium">Mark Photo: {photo.name}</h3>
                    <button onClick={onClose} className="text-brand-gray-400 hover:text-brand-gray-700">&times;</button>
                </div>
                
                <div className="p-2 bg-brand-gray-100 flex items-center gap-4 justify-center flex-wrap">
                    <label className="flex items-center gap-2 text-sm">Color: <input type="color" value={color} onChange={e => setColor(e.target.value)} className="w-8 h-8" /></label>
                    <label className="flex items-center gap-2 text-sm">Brush Size: <input type="range" min="2" max="20" value={lineWidth} onChange={e => setLineWidth(Number(e.target.value))} /></label>
                    <button onClick={clearCanvas} className="px-3 py-1 text-sm border rounded-md bg-white hover:bg-brand-gray-50">Clear</button>
                </div>

                <div className="p-4 flex-grow overflow-auto flex justify-center items-center">
                    <div className="relative" style={{ aspectRatio: 'auto' }}>
                        <img src={photo.dataUrl} alt="Inspection" className="max-w-full max-h-[65vh] object-contain" />
                        <canvas
                            ref={canvasRef}
                            className="absolute top-0 left-0 w-full h-full cursor-crosshair"
                            onMouseDown={startDrawing}
                            onMouseMove={draw}
                            onMouseUp={stopDrawing}
                            onMouseLeave={stopDrawing}
                            onTouchStart={startDrawing}
                            onTouchMove={draw}
                            onTouchEnd={stopDrawing}
                        />
                    </div>
                </div>

                <div className="p-4 border-t flex justify-end gap-4">
                    <button onClick={onClose} className="px-4 py-2 rounded-lg bg-brand-gray-200 text-brand-gray-800 hover:bg-brand-gray-300 transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-6 py-2 rounded-lg font-semibold text-white bg-brand-blue hover:shadow-lg transition-shadow">Save Markings</button>
                </div>
            </div>
        </div>
    );
};

export default PhotoEditor;