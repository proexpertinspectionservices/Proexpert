import React from 'react';

const CustomInput = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input 
        {...props} 
        className="w-full px-4 py-2 bg-white/80 border border-brand-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-orange focus:border-brand-blue transition" 
    />
);

const CustomTextarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
    <textarea 
        {...props} 
        className="w-full px-4 py-2 bg-white/80 border border-brand-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-orange focus:border-brand-blue transition"
    />
);

const ProjectView: React.FC<{ inspection: any, updateProjectDetails: any }> = ({ inspection, updateProjectDetails }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/50 overflow-hidden">
      <h2 className="text-2xl font-bold text-brand-blue mb-6">Step 1: Basic Details</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-brand-gray-700 mb-1">Project Name</label>
          <CustomInput
            type="text"
            id="projectName"
            value={inspection.projectName}
            onChange={(e) => updateProjectDetails('projectName', e.target.value)}
            placeholder="e.g., Downtown Residential Tower"
          />
        </div>
        <div>
          <label htmlFor="clientName" className="block text-sm font-medium text-brand-gray-700 mb-1">Client Name</label>
          <CustomInput
            type="text"
            id="clientName"
            value={inspection.clientName}
            onChange={(e) => updateProjectDetails('clientName', e.target.value)}
            placeholder="e.g., Ms. Jane Smith"
          />
        </div>
        <div className="md:col-span-2">
          <label htmlFor="address" className="block text-sm font-medium text-brand-gray-700 mb-1">Address</label>
          <CustomTextarea
            id="address"
            rows={3}
            value={inspection.address}
            onChange={(e) => updateProjectDetails('address', e.target.value)}
            placeholder="Enter full property address"
          />
        </div>
         <div>
          <label htmlFor="blockPhase" className="block text-sm font-medium text-brand-gray-700 mb-1">Block / Phase</label>
          <CustomInput
            type="text"
            id="blockPhase"
            value={inspection.blockPhase}
            onChange={(e) => updateProjectDetails('blockPhase', e.target.value)}
            placeholder="e.g., Block A"
          />
        </div>
        <div>
          <label htmlFor="unitNumber" className="block text-sm font-medium text-brand-gray-700 mb-1">Unit Number</label>
          <CustomInput
            type="text"
            id="unitNumber"
            value={inspection.unitNumber}
            onChange={(e) => updateProjectDetails('unitNumber', e.target.value)}
            placeholder="e.g., #12-345"
          />
        </div>
        <div>
          <label htmlFor="inspector" className="block text-sm font-medium text-brand-gray-700 mb-1">Inspector</label>
          <CustomInput
            type="text"
            id="inspector"
            value={inspection.inspector}
            onChange={(e) => updateProjectDetails('inspector', e.target.value)}
            placeholder="Your name"
          />
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-brand-gray-700 mb-1">Date</label>
          <CustomInput
            type="date"
            id="date"
            value={inspection.date}
            onChange={(e) => updateProjectDetails('date', e.target.value)}
          />
        </div>
      </div>
    </div>
  );
};

export default ProjectView;