import React from 'react';
import { Inspection, WorkStatus } from '../types';
import { generateCsv, generatePdf } from '../utils/reportUtils';
import { getRoomIconComponent, getElementIconComponent, getWorkStatusIcon } from '../utils/iconUtils';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { PrinterIcon } from './icons/PrinterIcon';
import { WhatsAppIcon } from './icons/WhatsAppIcon';

declare var jspdf: any;

interface ReportViewProps {
  inspection: Inspection;
}

const workStatusStyles: Record<WorkStatus, { icon: React.FC<React.SVGProps<SVGSVGElement>>; colors: string }> = {
  [WorkStatus.Completed]: { icon: getWorkStatusIcon(WorkStatus.Completed), colors: 'bg-green-100 text-green-800' },
  [WorkStatus.Attention]: { icon: getWorkStatusIcon(WorkStatus.Attention), colors: 'bg-yellow-100 text-yellow-800' },
  [WorkStatus.Issue]: { icon: getWorkStatusIcon(WorkStatus.Issue), colors: 'bg-red-100 text-red-800' },
};

const ReportView: React.FC<ReportViewProps> = ({ inspection }) => {
  const hasData = inspection.floors.some(floor => floor.rooms.some(room => room.elements.length > 0));
  const canShareFiles = typeof navigator.share === 'function' && typeof navigator.canShare === 'function';

  const handleDownloadPdf = () => {
    if (!hasData) return;
    const pdf = generatePdf(inspection);
    const filename = `inspection-report-${inspection.projectName.replace(/\s+/g, '-')}-${inspection.date}.pdf`;
    pdf.save(filename);
  };
  
  const handleWhatsAppShare = async () => {
    if (!hasData) return;
    
    const pdf = generatePdf(inspection);
    const pdfBlob = pdf.output('blob');
    const filename = `inspection-report-${inspection.projectName.replace(/\s+/g, '-')}-${inspection.date}.pdf`;
    const pdfFile = new File([pdfBlob], filename, { type: 'application/pdf' });

    if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
      try {
        await navigator.share({
          title: `Inspection Report: ${inspection.projectName}`,
          text: `Please find the attached inspection report for ${inspection.projectName}.`,
          files: [pdfFile],
        });
      } catch (error) {
        console.error('Error sharing file:', error);
        alert('Could not share the file. Please try downloading it instead.');
      }
    } else {
       alert('Your browser does not support sharing files directly. Please download the PDF and share it manually.');
    }
  };


  return (
    <div className="bg-white/80 backdrop-blur-sm p-4 sm:p-6 lg:p-8 rounded-xl shadow-lg border border-white/50">
      <div className="flex flex-wrap justify-between items-center gap-4 mb-6 print:hidden">
        <h2 className="text-3xl font-bold text-brand-gray-900">Inspection Report</h2>
        <div className="flex flex-wrap gap-3">
           <button
            onClick={() => generateCsv(inspection)}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg text-brand-gray-700 bg-white/80 hover:bg-white border border-brand-gray-300 shadow-sm transition-all disabled:opacity-50"
            disabled={!hasData}
          >
            <DocumentTextIcon className="w-5 h-5"/>
            CSV
          </button>
          <button
            onClick={handleDownloadPdf}
            className="flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-bold rounded-lg text-white bg-brand-blue hover:shadow-lg transition-shadow disabled:opacity-50"
            disabled={!hasData}
          >
            <PrinterIcon className="w-5 h-5"/>
            PDF
          </button>
           {canShareFiles && (
            <button
                onClick={handleWhatsAppShare}
                className="flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-green-500 hover:bg-green-600 shadow-sm hover:shadow-lg transition-all disabled:opacity-50"
                disabled={!hasData}
            >
                <WhatsAppIcon />
                Share
            </button>
           )}
        </div>
      </div>

      <div className="prose prose-sm sm:prose-base max-w-none">
        <div className="not-prose border-b pb-8 mb-8">
            <h1 className="text-4xl font-bold text-brand-gray-900">{inspection.projectName || 'N/A'}</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6 mt-6">
                <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Address</h3>
                    <p className="text-lg font-semibold text-brand-gray-900 whitespace-pre-wrap">{inspection.address || 'N/A'}</p>
                </div>
                 <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Block / Phase</h3>
                    <p className="text-lg font-semibold text-brand-gray-900">{inspection.blockPhase || 'N/A'}</p>
                </div>
                <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Unit Number</h3>
                    <p className="text-lg font-semibold text-brand-gray-900">{inspection.unitNumber || 'N/A'}</p>
                </div>
                <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Client Name</h3>
                    <p className="text-lg font-semibold text-brand-gray-900">{inspection.clientName || 'N/A'}</p>
                </div>
                <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Inspector</h3>
                    <p className="text-lg font-semibold text-brand-gray-900">{inspection.inspector || 'N/A'}</p>
                </div>
                <div>
                    <h3 className="text-sm font-medium text-brand-gray-500">Inspection Date</h3>
                    <p className="text-lg font-semibold text-brand-gray-900">{inspection.date || 'N/A'}</p>
                </div>
            </div>
        </div>
        
        {!hasData && (
          <div className="text-center py-16 border-2 border-dashed rounded-lg">
            <h3 className="text-lg font-medium">No Inspection Data</h3>
            <p className="text-brand-gray-500">Go to the inspection form to add floors, rooms and elements.</p>
          </div>
        )}

        {inspection.floors.map(floor => (
          <div key={floor.id} className="mb-8 page-break-before-always">
            <h2 className="text-2xl font-bold text-white bg-brand-blue -mx-3 px-3 py-2 rounded-md mb-6">{floor.name}</h2>
            {floor.rooms.map(room => {
              const RoomIcon = getRoomIconComponent(room.name);
              return room.elements.length > 0 && (
                <div key={room.id} className="mb-8 page-break-inside-avoid">
                  <h3 className="text-xl font-semibold text-brand-gray-800 bg-brand-gray-100/80 p-3 rounded-t-lg flex items-center gap-3">
                    {RoomIcon && <RoomIcon className="w-6 h-6 text-brand-blue" />}
                    <span>{room.name}</span>
                  </h3>
                  <div className="border border-t-0 rounded-b-lg p-4">
                  {room.elements.map(element => {
                    const ElementIcon = getElementIconComponent(element.elementType);
                    const status = workStatusStyles[element.workStatus];
                    const StatusIcon = status.icon;

                    return (
                    <div key={element.id} className="mb-6 pb-6 border-b last:border-b-0 page-break-inside-avoid">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <h4 className="font-bold text-lg flex items-center gap-2 text-brand-blue">
                                  {ElementIcon && <ElementIcon className="w-5 h-5" />}
                                  <span>{element.elementType}</span>
                                </h4>
                            </div>
                            <div className="md:col-span-2">
                                <p><strong className="font-medium text-brand-gray-600">Status:</strong> 
                                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-semibold rounded-full ${status.colors}`}>
                                        <StatusIcon className="w-3 h-3" />
                                        {element.workStatus}
                                    </span>
                                </p>
                                {element.problems.length > 0 && <p className="mt-2"><strong className="font-medium text-brand-gray-600">Problems:</strong> {element.problems.join(', ')}</p>}
                                {element.notes && <p className="mt-2 whitespace-pre-wrap"><strong className="font-medium text-brand-gray-600">Remarks:</strong> {element.notes}</p>}
                            </div>
                        </div>
                        {element.photos.length > 0 && (
                            <div className="mt-4">
                                <strong className="font-medium text-brand-gray-600">Photos:</strong>
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-2">
                                    {element.photos.map(photo => (
                                        <div key={photo.id} className="relative aspect-square">
                                            <img src={photo.dataUrl} alt={photo.name} className="w-full h-full object-cover rounded-md" />
                                            {photo.markings && <img src={photo.markings} className="absolute top-0 left-0 w-full h-full object-cover" />}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                  )})}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
       <style>{`
          .page-break-inside-avoid { page-break-inside: avoid; }
          .page-break-before-always { page-break-before: always; }
          @media print {
            .prose {
                font-size: 10px;
            }
          }
      `}</style>
    </div>
  );
};

export default ReportView;