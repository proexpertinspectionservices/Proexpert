import React, { useState } from 'react';
import { useInspection } from '../hooks/useInspection';
import { ElementType } from '../types';
import FloorComponent from './FloorComponent';
import ProjectView from './ProjectView';
import { PlusIcon } from './icons/PlusIcon';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
import { ArrowRightIcon } from './icons/ArrowRightIcon';

interface InspectionWizardProps {
  inspectionApi: ReturnType<typeof useInspection>;
  onNavigateToElement: (floorId: string, roomId: string, elementId: string) => void;
  onAddElement: (floorId: string, roomId: string, elementType: ElementType) => void;
}

const InspectionWizard: React.FC<InspectionWizardProps> = ({ inspectionApi, onNavigateToElement, onAddElement }) => {
  const { inspection, addFloor, updateFloor, deleteFloor, addRoom, updateRoom, deleteRoom, deleteElement } = inspectionApi;
  const [step, setStep] = useState(0);

  const detailsAreComplete = !!(
    inspection.projectName?.trim() &&
    inspection.address?.trim() &&
    inspection.clientName?.trim() &&
    inspection.date?.trim() &&
    inspection.inspector?.trim()
  );

  const steps = [
    {
      name: 'Project Details',
      component: <ProjectView inspection={inspection} updateProjectDetails={inspectionApi.updateProjectDetails} />,
      isComplete: detailsAreComplete
    },
    {
      name: 'Floors & Rooms',
      component: (
        <>
          {inspection.floors.map(floor => (
            <FloorComponent
              key={floor.id}
              floor={floor}
              onUpdateFloor={updateFloor}
              onDeleteFloor={deleteFloor}
              onAddRoom={() => addRoom(floor.id)}
              onUpdateRoom={(roomId, name) => updateRoom(floor.id, roomId, name)}
              onDeleteRoom={(roomId) => deleteRoom(floor.id, roomId)}
              onAddElement={(roomId, elementType) => onAddElement(floor.id, roomId, elementType)}
              onDeleteElement={(roomId, elementId) => deleteElement(floor.id, roomId, elementId)}
              onNavigateToElement={(roomId, elementId) => onNavigateToElement(floor.id, roomId, elementId)}
            />
          ))}
          <button
            onClick={addFloor}
            className="mt-6 w-full flex items-center justify-center gap-2 px-6 py-3 border-2 border-dashed border-brand-gray-300 text-brand-gray-600 rounded-lg hover:border-brand-orange hover:text-brand-blue transition-colors duration-200"
          >
            <PlusIcon />
            Add Floor
          </button>
        </>
      ),
      isComplete: inspection.floors.length > 0
    }
  ];
  
  const currentStep = steps[step];

  return (
    <div>
      <div className="mb-8">
        {/* Render current step component */}
        <div className="transition-opacity duration-300">
            {currentStep.component}
        </div>
      </div>
      
      {/* Navigation */}
      <div className="flex justify-between items-center mt-8 p-4 bg-white/50 backdrop-blur-sm rounded-lg shadow-md sticky bottom-4">
        <button
          onClick={() => setStep(s => Math.max(0, s - 1))}
          disabled={step === 0}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg text-brand-gray-700 bg-white/80 hover:bg-white border border-brand-gray-300 shadow-sm transition-all disabled:opacity-50"
        >
          <ArrowLeftIcon className="w-4 h-4" />
          Previous
        </button>
        <div className="text-sm font-medium text-brand-gray-600">
            Step {step + 1} of {steps.length}: <span className="font-bold text-brand-blue">{currentStep.name}</span>
        </div>
        <button
          onClick={() => setStep(s => Math.min(steps.length - 1, s + 1))}
          disabled={step === steps.length - 1 || !currentStep.isComplete}
          className="flex items-center gap-2 px-6 py-2 border border-transparent text-sm font-bold rounded-lg text-white bg-brand-blue hover:shadow-lg transition-shadow disabled:opacity-50 disabled:shadow-none"
        >
          Next
          <ArrowRightIcon className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default InspectionWizard;