import React, { useState } from 'react';
import { Floor, Room, ElementType, InspectionElement, WorkStatus } from '../types';
import { ELEMENT_TYPES } from '../utils/checklistData';
import { PREDEFINED_FLOORS, PREDEFINED_ROOMS } from '../utils/selectionData';
import { getRoomIconComponent, getElementIconComponent, getWorkStatusIcon } from '../utils/iconUtils';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';

interface FloorComponentProps {
  floor: Floor;
  onUpdateFloor: (floorId: string, name: string) => void;
  onDeleteFloor: (floorId: string) => void;
  onAddRoom: () => void;
  onUpdateRoom: (roomId: string, name: string) => void;
  onDeleteRoom: (roomId: string) => void;
  onAddElement: (roomId: string, elementType: ElementType) => void;
  onDeleteElement: (roomId: string, elementId: string) => void;
  onNavigateToElement: (roomId: string, elementId: string) => void;
}

const workStatusColors: Record<WorkStatus, string> = {
  [WorkStatus.Completed]: 'text-green-600',
  [WorkStatus.Attention]: 'text-yellow-600',
  [WorkStatus.Issue]: 'text-red-600',
};

const ElementTag: React.FC<{element: InspectionElement, onClick: () => void, onDelete: () => void}> = ({ element, onClick, onDelete }) => {
    const ElementIcon = getElementIconComponent(element.elementType);
    const StatusIcon = getWorkStatusIcon(element.workStatus);
    return (
        <div className="group relative flex items-center justify-between bg-brand-gray-100/80 rounded-lg text-sm pl-3 pr-2 py-1.5 hover:bg-brand-gray-200/80 transition-colors">
           <button onClick={onClick} className="flex-grow text-left flex items-center gap-2 text-brand-gray-700">
                {StatusIcon && <StatusIcon className={`w-4 h-4 ${workStatusColors[element.workStatus]}`} />}
                {ElementIcon && <ElementIcon className="w-4 h-4 text-brand-gray-600" />}
                <span>{element.elementType}</span>
           </button>
           <button 
                onClick={(e) => { e.stopPropagation(); onDelete(); }}
                className="opacity-0 group-hover:opacity-100 text-brand-gray-400 hover:text-red-500 transition-opacity"
            >
                <TrashIcon className="w-4 h-4" />
            </button>
        </div>
    )
}


const AddElementMenu: React.FC<{ onAddElement: (elementType: ElementType) => void }> = ({ onAddElement }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="relative">
            <button onBlur={() => setIsOpen(false)} onClick={() => setIsOpen(!isOpen)} className="w-full flex items-center justify-center gap-2 px-2 py-1 border-2 border-dashed border-brand-gray-300 text-brand-gray-500 rounded-lg hover:border-brand-orange hover:text-brand-blue text-sm transition-all">
                <PlusIcon className="w-4 h-4" /> Add Element
            </button>
            {isOpen && (
                <div className="absolute top-full mt-1 w-48 bg-white rounded-md shadow-lg border z-10 animate-fade-in-down">
                    {ELEMENT_TYPES.map(type => {
                        const ElementIcon = getElementIconComponent(type);
                        return (
                            <button 
                                key={type} 
                                onMouseDown={() => { onAddElement(type); setIsOpen(false); }}
                                className="block w-full text-left px-4 py-2 text-sm text-brand-gray-700 hover:bg-brand-gray-100 flex items-center gap-2"
                            >
                                {ElementIcon && <ElementIcon className="w-4 h-4 text-brand-gray-500" />}
                                {type}
                            </button>
                        )
                    })}
                </div>
            )}
        </div>
    )
}

const RoomItem: React.FC<{room: Room, onUpdate: (name: string) => void, onDelete: () => void, children: React.ReactNode}> = ({ room, onUpdate, onDelete, children }) => {
    const isRoomNamePredefined = PREDEFINED_ROOMS.includes(room.name);
    const RoomIcon = getRoomIconComponent(room.name);
    return (
        <div className="bg-white/80 backdrop-blur-sm rounded-lg border border-white/60 shadow-md p-4 transition-shadow hover:shadow-lg">
            <div className="flex justify-between items-center mb-3 gap-2">
                <div className="flex-grow flex flex-wrap items-center gap-2">
                    {RoomIcon && <RoomIcon className="w-5 h-5 text-brand-blue" />}
                    <select
                        value={isRoomNamePredefined ? room.name : 'Other'}
                        onChange={(e) => {
                            if (e.target.value === 'Other') {
                                onUpdate('');
                            } else {
                                onUpdate(e.target.value);
                            }
                        }}
                        className="font-semibold text-brand-gray-800 bg-transparent focus:outline-none focus:ring-1 focus:ring-brand-orange rounded px-1 -ml-1 flex-shrink-0"
                    >
                        {PREDEFINED_ROOMS.map(name => <option key={name} value={name}>{name}</option>)}
                        <option value="Other">Other...</option>
                    </select>
                     {!isRoomNamePredefined && (
                        <input
                            type="text"
                            value={room.name}
                            onChange={(e) => onUpdate(e.target.value)}
                            className="font-semibold text-brand-gray-800 bg-transparent focus:outline-none focus:ring-1 focus:ring-brand-orange rounded px-1 flex-grow min-w-[100px]"
                            placeholder="Custom Room"
                            autoFocus
                        />
                    )}
                </div>
                <button onClick={onDelete} className="p-1 rounded-full text-brand-gray-400 hover:bg-red-100 hover:text-red-500 flex-shrink-0 transition-colors">
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
            {children}
        </div>
    )
}

const FloorComponent: React.FC<FloorComponentProps> = (props) => {
  const isFloorNamePredefined = PREDEFINED_FLOORS.includes(props.floor.name);
  return (
    <div className="bg-white/60 backdrop-blur-sm rounded-xl shadow-lg mb-6 border border-white/50 overflow-hidden">
      <div className="p-5 bg-brand-blue text-white flex justify-between items-center gap-4">
        <div className="flex-grow flex flex-wrap items-center gap-2">
            <select
                value={isFloorNamePredefined ? props.floor.name : 'Other'}
                onChange={(e) => {
                    if (e.target.value === 'Other') {
                        props.onUpdateFloor(props.floor.id, '');
                    } else {
                        props.onUpdateFloor(props.floor.id, e.target.value);
                    }
                }}
                className="text-xl font-bold bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-orange rounded-md px-2 py-1 -ml-2 appearance-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
                  backgroundPosition: 'right 0.5rem center',
                  backgroundRepeat: 'no-repeat',
                  backgroundSize: '1.5em 1.5em',
                  paddingRight: '2.5rem',
                }}
            >
                {PREDEFINED_FLOORS.map(name => <option key={name} value={name} className="text-black">{name}</option>)}
                <option value="Other" className="text-black">Other...</option>
            </select>
            {!isFloorNamePredefined && (
                 <input
                  type="text"
                  value={props.floor.name}
                  onChange={(e) => props.onUpdateFloor(props.floor.id, e.target.value)}
                  className="text-xl font-bold placeholder-gray-300 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-orange rounded-md px-2 py-1"
                  placeholder="Custom Floor Name"
                  autoFocus
                />
            )}
        </div>
        <button
          onClick={() => props.onDeleteFloor(props.floor.id)}
          className="p-2 rounded-full text-gray-300 hover:bg-white/10 hover:text-white transition-colors flex-shrink-0"
        >
          <TrashIcon />
        </button>
      </div>
      <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {props.floor.rooms.map(room => (
            <RoomItem 
                key={room.id}
                room={room}
                onUpdate={(name) => props.onUpdateRoom(room.id, name)}
                onDelete={() => props.onDeleteRoom(room.id)}
            >
                <div className="grid grid-cols-2 gap-2">
                    {room.elements.map(el => (
                       <ElementTag 
                            key={el.id} 
                            element={el}
                            onClick={() => props.onNavigateToElement(room.id, el.id)}
                            onDelete={() => props.onDeleteElement(room.id, el.id)}
                        />
                    ))}
                    <AddElementMenu onAddElement={(type) => props.onAddElement(room.id, type)} />
                </div>
            </RoomItem>
        ))}
        <button
            onClick={props.onAddRoom}
            className="flex flex-col items-center justify-center gap-2 p-4 border-2 border-dashed border-brand-gray-300 text-brand-gray-500 rounded-lg hover:border-brand-orange hover:text-brand-blue transition-colors min-h-[120px]"
        >
          <PlusIcon />
          Add Room
        </button>
      </div>
    </div>
  );
};

export default FloorComponent;