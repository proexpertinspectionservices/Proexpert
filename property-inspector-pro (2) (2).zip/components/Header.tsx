import React from 'react';
import { ProexpertLogo } from './icons/ProexpertLogo';

interface HeaderProps {
  resetInspection: () => void;
}

const Header: React.FC<HeaderProps> = ({ resetInspection }) => {

  const handleReset = () => {
    if (window.confirm('Are you sure you want to start a new inspection? All current data will be lost.')) {
        resetInspection();
    }
  }

  return (
    <header className="bg-brand-blue text-white shadow-lg sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-3">
            <ProexpertLogo className="h-12" />
            <div className="hidden sm:block border-l border-white/30 pl-3 ml-1">
                 <p className="text-sm font-light text-gray-200">Smart Property Inspection Made Simple</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
             <button
                onClick={handleReset}
                className="px-4 py-2 text-sm font-medium rounded-md text-gray-200 hover:bg-white/10 hover:text-white transition-colors"
            >
                New Inspection
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;