import React, { useState, useEffect, useRef } from 'react';
import { MicrophoneIcon } from './icons/MicrophoneIcon';

// Fix: Add types for the Web Speech API to prevent TypeScript errors.
interface SpeechRecognitionEvent extends Event {
    results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
    item(index: number): SpeechRecognitionResult;
    [index: number]: SpeechRecognitionResult;
    length: number;
}

interface SpeechRecognitionResult {
    [index: number]: SpeechRecognitionAlternative;
    isFinal: boolean;
}

interface SpeechRecognitionAlternative {
    transcript: string;
}

interface SpeechRecognitionErrorEvent extends Event {
    error: string;
}

interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    start(): void;
    stop(): void;
    onresult: (event: SpeechRecognitionEvent) => void;
    onerror: (event: SpeechRecognitionErrorEvent) => void;
    onend: () => void;
}

declare global {
    interface Window {
        SpeechRecognition: new () => SpeechRecognition;
        webkitSpeechRecognition: new () => SpeechRecognition;
    }
}


interface VoiceInputProps {
    onTranscript: (transcript: string) => void;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ onTranscript }) => {
    const [isListening, setIsListening] = useState(false);
    const recognitionRef = useRef<SpeechRecognition | null>(null);

    // Fix: Use refs to hold the latest state and props for use in event handlers
    // to avoid stale closures without re-triggering the useEffect.
    const onTranscriptRef = useRef(onTranscript);
    onTranscriptRef.current = onTranscript;
    const isListeningRef = useRef(isListening);
    isListeningRef.current = isListening;


    useEffect(() => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            console.warn("Speech Recognition not supported by this browser.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = false; // Process final results only
        recognition.lang = 'en-US';

        recognition.onresult = (event) => {
            const last = event.results.length - 1;
            const transcript = event.results[last][0].transcript.trim();
            onTranscriptRef.current(transcript);
        };
        
        recognition.onerror = (event) => {
            console.error('Speech recognition error', event.error);
            setIsListening(false);
        };

        recognition.onend = () => {
            // Fix: Use ref to get current listening state.
            if (isListeningRef.current) {
                // Restart recognition if it stops unexpectedly.
                try {
                    recognition.start();
                } catch(e) {
                    console.error("Could not restart recognition", e);
                    setIsListening(false);
                }
            }
        };

        recognitionRef.current = recognition;

        return () => {
            if (recognitionRef.current) {
                recognitionRef.current.stop();
            }
        };
    }, []);

    const toggleListening = () => {
        if (!recognitionRef.current) return;

        if (isListening) {
            // Fix: Update ref before stopping to prevent onend from restarting.
            isListeningRef.current = false;
            recognitionRef.current.stop();
            setIsListening(false);
        } else {
            try {
                recognitionRef.current.start();
                setIsListening(true);
            } catch (e) {
                console.error("Could not start recognition", e);
            }
        }
    };
    
    // Fix: The separate useEffect for cleanup was redundant and has been removed.
    // Cleanup is now handled in the main useEffect.

    // Fix: The check for support was flawed. Check the window object directly.
    if (!(typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition))) {
        return null; // Don't render if not supported
    }

    return (
        <button
            type="button"
            onClick={toggleListening}
            title={isListening ? 'Stop dictation' : 'Start dictation'}
            className={`absolute top-2 right-2 p-1.5 rounded-full transition-colors ${
                isListening 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-brand-gray-100 text-brand-gray-600 hover:bg-brand-blue hover:text-white'
            }`}
        >
            <MicrophoneIcon className="w-4 h-4" />
        </button>
    );
};

export default VoiceInput;
