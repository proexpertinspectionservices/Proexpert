import React from 'react';

export const ElectricalIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M12 2.69l3.09 6.26L22 9.35l-5.32 5.18 1.26 7.41-6.94-3.65-6.94 3.65 1.26-7.41L2 9.35l6.91-.4L12 2.69z" />
    </svg>
);
