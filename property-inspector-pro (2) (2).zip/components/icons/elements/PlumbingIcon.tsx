import React from 'react';

export const PlumbingIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M12 3v3" />
        <path d="m19 4-2 2" />
        <path d="M5 4l2 2" />
        <path d="M12 21a9 9 0 0 0-9-9" />
        <path d="M15.5 16a2.5 2.5 0 0 0 0-5h-5a2.5 2.5 0 0 0 0 5" />
        <path d="M21 12a9 9 0 0 0-9-9" />
    </svg>
);
