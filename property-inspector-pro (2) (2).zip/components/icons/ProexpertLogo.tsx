import React from 'react';

export const ProexpertLogo = (props: React.SVGProps<SVGSVGElement>) => (
  <svg 
    viewBox="0 0 430 110" 
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <style>{`.pro-text { font-family: Roboto, Arial, sans-serif; font-weight: 700; }`}</style>
    
    {/* House shape, simplified and clean */}
    <path d="M20 45 v40 c0 8 7 15 15 15 h80 v-55 h-95 Z" fill="#F6A31A" />
    <path d="M15 45 L 77.5 5 L 140 45 Z" fill="#F6A31A"/>
    
    {/* Magnifier handle */}
    <path d="M185 88 H 410" stroke="#F6A31A" strokeWidth="14" strokeLinecap="round"/>
    
    {/* Magnifier glass ('O' of PRO) */}
    <circle cx="160" cy="66" r="28" fill="none" stroke="#F6A31A" strokeWidth="14" />
    
    {/* Windows */}
    <rect x="42" y="58" width="24" height="24" fill="#004AAD" />
    <rect x="84" y="58" width="24" height="24" fill="#004AAD" />

    {/* Text */}
    {/* "PR" text inside the house shape */}
    <text x="63" y="90" textAnchor="middle" className="pro-text" fontSize="40" fill="white">PR</text>
    {/* "EXPERT" text */}
    <text x="200" y="78" className="pro-text" fontSize="52" fill="#004AAD">EXPERT</text>
    {/* "SERVICES" text */}
    <text x="200" y="102" className="pro-text" fontSize="22" letterSpacing="0.5" fill="#004AAD">SERVICES</text>
  </svg>
);