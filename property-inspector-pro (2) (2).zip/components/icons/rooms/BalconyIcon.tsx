import React from 'react';

export const BalconyIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M4 13c0-2.93 2.07-5.18 5-5.65A5.99 5.99 0 0 1 12 2a6 6 0 0 1 6 6c0 1.9-1.2 3.52-2.79 4.93" />
        <path d="M12 22A6.99 6.99 0 0 0 19 15h-1a3 3 0 1 1-6 0H5a6.99 6.99 0 0 0 7 7Z" />
    </svg>
);
