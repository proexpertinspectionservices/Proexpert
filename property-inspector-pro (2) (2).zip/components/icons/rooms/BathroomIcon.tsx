import React from 'react';

export const BathroomIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M8 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-1" />
        <path d="M12 3h.01" />
        <path d="M12 7h.01" />
        <path d="M12 11h.01" />
        <path d="M12 15h.01" />
        <path d="M12 19h.01" />
        <path d="M3 15h.01" />
        <path d="M21 15h.01" />
        <path d="M3 11h.01" />
        <path d="M21 11h.01" />
        <path d="M3 7h.01" />
        <path d="M21 7h.01" />
    </svg>
);
