import React, { useState } from 'react';
import { Photo } from '../types';
import { CameraIcon } from './icons/CameraIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PencilIcon } from './icons/PencilIcon';
import PhotoEditor from './PhotoEditor';

interface PhotoUploaderProps {
  photos: Photo[];
  onUpdatePhotos: (photos: Photo[]) => void;
}

const PhotoUploader: React.FC<PhotoUploaderProps> = ({ photos, onUpdatePhotos }) => {
  const [editingPhoto, setEditingPhoto] = useState<Photo | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newPhotosPromises = Array.from(event.target.files).map(file => {
        return new Promise<Photo>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            if (e.target && typeof e.target.result === 'string') {
              resolve({
                id: crypto.randomUUID(),
                name: file.name,
                dataUrl: e.target.result,
              });
            }
          };
          reader.readAsDataURL(file);
        });
      });

      Promise.all(newPhotosPromises).then(newPhotos => {
        onUpdatePhotos([...photos, ...newPhotos]);
      });
    }
    event.target.value = '';
  };

  const handleDeletePhoto = (photoId: string) => {
    onUpdatePhotos(photos.filter(p => p.id !== photoId));
  };
  
  const handleSaveMarkings = (photoId: string, markingsDataUrl: string) => {
      const updatedPhotos = photos.map(p => 
        p.id === photoId ? { ...p, markings: markingsDataUrl } : p
      );
      onUpdatePhotos(updatedPhotos);
      setEditingPhoto(null);
  };


  return (
    <div>
      <h4 className="text-sm font-medium text-brand-gray-700 mb-2">Photos</h4>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {photos.map(photo => (
          <div key={photo.id} className="relative group aspect-square">
            <img 
                src={photo.dataUrl} 
                alt={photo.name} 
                className="w-full h-full object-cover rounded-md shadow-sm" 
            />
            {photo.markings && (
                <img src={photo.markings} className="absolute top-0 left-0 w-full h-full object-cover pointer-events-none" />
            )}
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center gap-2">
                <button onClick={() => setEditingPhoto(photo)} title="Edit Markings" className="p-2 bg-white/80 text-brand-gray-800 rounded-full opacity-0 group-hover:opacity-100 hover:bg-white transition-all">
                    <PencilIcon className="w-5 h-5" />
                </button>
                <button onClick={() => handleDeletePhoto(photo.id)} title="Delete Photo" className="p-2 bg-white/80 text-red-600 rounded-full opacity-0 group-hover:opacity-100 hover:bg-white transition-all">
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
          </div>
        ))}
        <label className="cursor-pointer aspect-square flex flex-col items-center justify-center border-2 border-dashed border-brand-gray-300 rounded-md text-brand-gray-500 hover:border-brand-blue hover:text-brand-blue transition-colors">
          <CameraIcon className="w-8 h-8" />
          <span className="text-sm mt-1 text-center">Add Photo</span>
          <input type="file" multiple accept="image/*" onChange={handleFileChange} className="hidden" />
        </label>
      </div>
      {editingPhoto && (
        <PhotoEditor 
            photo={editingPhoto}
            onSave={handleSaveMarkings}
            onClose={() => setEditingPhoto(null)}
        />
      )}
    </div>
  );
};

export default PhotoUploader;
