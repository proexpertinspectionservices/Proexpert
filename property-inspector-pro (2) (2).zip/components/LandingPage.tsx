import React from 'react';
import { ProexpertLogo } from './icons/ProexpertLogo';

interface LandingPageProps {
    onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
    return (
        <div className="flex flex-col items-center justify-center text-center py-20">
            <ProexpertLogo className="h-24 md:h-32 mb-6" />
            <h1 className="text-xl md:text-2xl font-light text-brand-gray-700">
                Smart Property Inspection Made Simple
            </h1>
            <button
                onClick={onStart}
                className="mt-12 px-10 py-4 text-lg font-bold text-white rounded-xl shadow-lg bg-brand-blue hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-blue-500/50"
            >
                Start New Inspection
            </button>
        </div>
    );
};

export default LandingPage;