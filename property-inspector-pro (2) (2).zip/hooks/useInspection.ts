import { useState, useCallback } from 'react';
// Fix: Import all necessary types for the new nested data structure.
import { Inspection, Floor, Room, InspectionElement, WorkStatus, ElementType } from '../types';

const getInitialState = (): Inspection => {
  try {
    const savedState = localStorage.getItem('inspectionData');
    if (savedState) {
      // Fix: Add basic validation to ensure loaded state matches the new structure.
      const parsed = JSON.parse(savedState);
      if (parsed.floors) {
          return parsed;
      }
    }
    // Fix: Corrected catch block syntax to resolve parsing errors.
  } catch (e: any) {
    console.error("Could not load state from localStorage", e);
  }
  
  return {
    projectName: 'Skyline Tower',
    inspector: 'John Doe',
    date: new Date().toISOString().split('T')[0],
    address: '',
    blockPhase: '',
    unitNumber: '',
    clientName: '',
    // Fix: Initialize with `floors` array instead of `items`.
    floors: [],
  };
};

export const useInspection = () => {
  const [inspection, setInspection] = useState<Inspection>(getInitialState);

  const saveState = useCallback((newState: Inspection) => {
      setInspection(newState);
      try {
        localStorage.setItem('inspectionData', JSON.stringify(newState));
        // Fix: Corrected catch block syntax to resolve parsing errors.
      } catch (e: any) {
        console.error("Could not save state to localStorage", e);
      }
  }, []);

  const updateProjectDetails = useCallback((field: keyof Omit<Inspection, 'floors'>, value: string) => {
    saveState({ ...inspection, [field]: value });
  }, [inspection, saveState]);

  // Fix: Implement Floor management functions.
  const addFloor = useCallback(() => {
    const newFloor: Floor = {
      id: crypto.randomUUID(),
      name: `Floor ${inspection.floors.length + 1}`,
      rooms: [],
    };
    saveState({ ...inspection, floors: [...inspection.floors, newFloor] });
  }, [inspection, saveState]);
  
  const updateFloor = useCallback((floorId: string, name: string) => {
    const updatedFloors = inspection.floors.map(floor => 
      floor.id === floorId ? { ...floor, name } : floor
    );
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  const deleteFloor = useCallback((floorId: string) => {
    const updatedFloors = inspection.floors.filter(floor => floor.id !== floorId);
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  // Fix: Implement Room management functions.
  const addRoom = useCallback((floorId: string) => {
    const updatedFloors = inspection.floors.map(floor => {
      if (floor.id === floorId) {
        const newRoom: Room = {
          id: crypto.randomUUID(),
          name: `Room ${floor.rooms.length + 1}`,
          elements: [],
        };
        return { ...floor, rooms: [...floor.rooms, newRoom] };
      }
      return floor;
    });
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  const updateRoom = useCallback((floorId: string, roomId: string, name: string) => {
    const updatedFloors = inspection.floors.map(floor => {
      if (floor.id === floorId) {
        const updatedRooms = floor.rooms.map(room => 
          room.id === roomId ? { ...room, name } : room
        );
        return { ...floor, rooms: updatedRooms };
      }
      return floor;
    });
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  const deleteRoom = useCallback((floorId: string, roomId: string) => {
    const updatedFloors = inspection.floors.map(floor => {
      if (floor.id === floorId) {
        const updatedRooms = floor.rooms.filter(room => room.id !== roomId);
        return { ...floor, rooms: updatedRooms };
      }
      return floor;
    });
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  // Fix: Implement Element management functions.
  const addElement = useCallback((floorId: string, roomId: string, elementType: ElementType): string => {
    let newElementId = '';
    const updatedFloors = inspection.floors.map(floor => {
      if (floor.id === floorId) {
        const updatedRooms = floor.rooms.map(room => {
          if (room.id === roomId) {
            const newElement: InspectionElement = {
              id: crypto.randomUUID(),
              elementType,
              // Fix: Corrected the default work status to a valid enum member. 'NotStarted' does not exist.
              workStatus: WorkStatus.Attention,
              problems: [],
              notes: '',
              photos: [],
            };
            newElementId = newElement.id;
            return { ...room, elements: [...room.elements, newElement] };
          }
          return room;
        });
        return { ...floor, rooms: updatedRooms };
      }
      return floor;
    });
    saveState({ ...inspection, floors: updatedFloors });
    return newElementId;
  }, [inspection, saveState]);

  const updateElement = useCallback((floorId: string, roomId: string, elementId: string, updates: Partial<InspectionElement>) => {
      const updatedFloors = inspection.floors.map(floor => {
        if (floor.id === floorId) {
          const updatedRooms = floor.rooms.map(room => {
            if (room.id === roomId) {
              const updatedElements = room.elements.map(el =>
                el.id === elementId ? { ...el, ...updates } : el
              );
              return { ...room, elements: updatedElements };
            }
            return room;
          });
          return { ...floor, rooms: updatedRooms };
        }
        return floor;
      });
      saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);

  const deleteElement = useCallback((floorId: string, roomId: string, elementId: string) => {
    const updatedFloors = inspection.floors.map(floor => {
      if (floor.id === floorId) {
        const updatedRooms = floor.rooms.map(room => {
          if (room.id === roomId) {
            const updatedElements = room.elements.filter(el => el.id !== elementId);
            return { ...room, elements: updatedElements };
          }
          return room;
        });
        return { ...floor, rooms: updatedRooms };
      }
      return floor;
    });
    saveState({ ...inspection, floors: updatedFloors });
  }, [inspection, saveState]);
  
  const getElement = useCallback((floorId: string, roomId: string, elementId: string): InspectionElement | undefined => {
      const floor = inspection.floors.find(f => f.id === floorId);
      const room = floor?.rooms.find(r => r.id === roomId);
      return room?.elements.find(e => e.id === elementId);
  }, [inspection.floors]);


  const resetInspection = useCallback(() => {
    const freshState = {
      projectName: '',
      inspector: '',
      date: new Date().toISOString().split('T')[0],
      address: '',
      blockPhase: '',
      unitNumber: '',
      clientName: '',
      // Fix: reset `floors` array.
      floors: [],
    };
    saveState(freshState);
  }, [saveState]);

  // Fix: Export all the new state management functions.
  return {
    inspection,
    updateProjectDetails,
    addFloor,
    updateFloor,
    deleteFloor,
    addRoom,
    updateRoom,
    deleteRoom,
    addElement,
    updateElement,
    deleteElement,
    getElement,
    resetInspection
  };
};