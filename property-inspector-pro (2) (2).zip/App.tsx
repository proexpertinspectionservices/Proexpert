import React, { useState } from 'react';
import { useInspection } from './hooks/useInspection';
import Header from './components/Header';
import LandingPage from './components/LandingPage';
import InspectionWizard from './components/InspectionWizard';
import ReportView from './components/ReportView';
import ElementInspectionView from './components/ElementInspectionView';
import { ElementType } from './types';
// Fix: Import ProexpertLogo component to resolve usage in the footer.
import { ProexpertLogo } from './components/icons/ProexpertLogo';

type View = 'landing' | 'wizard' | 'report';

type EditingElement = {
    floorId: string;
    roomId: string;
    elementId: string;
};

const App: React.FC = () => {
  const inspectionApi = useInspection();
  const [currentView, setCurrentView] = useState<View>('landing');
  const [editingElement, setEditingElement] = useState<EditingElement | null>(null);

  const handleAddElement = (floorId: string, roomId: string, elementType: ElementType) => {
    const newElementId = inspectionApi.addElement(floorId, roomId, elementType);
    setEditingElement({ floorId, roomId, elementId: newElementId });
  };
  
  const handleNavigateToElement = (floorId: string, roomId: string, elementId: string) => {
    setEditingElement({ floorId, roomId, elementId });
  };
  
  const handleCloseElementView = () => {
    setEditingElement(null);
  };

  const renderContent = () => {
      if (currentView === 'landing') {
          return <LandingPage onStart={() => setCurrentView('wizard')} />;
      }
      
      if (editingElement) {
          return (
              <ElementInspectionView 
                  floorId={editingElement.floorId}
                  roomId={editingElement.roomId}
                  elementId={editingElement.elementId}
                  getElement={inspectionApi.getElement}
                  updateElement={inspectionApi.updateElement}
                  onClose={handleCloseElementView}
              />
          );
      }
      
      return (
          <>
            <div className="mb-6 border-b border-gray-200/50">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    <button
                        onClick={() => { setEditingElement(null); setCurrentView('wizard'); }}
                        className={`${
                            currentView === 'wizard' && !editingElement
                            ? 'border-brand-orange text-brand-blue'
                            : 'border-transparent text-gray-500 hover:text-brand-blue hover:border-gray-300'
                        } whitespace-nowrap py-4 px-1 border-b-4 font-medium text-sm transition-colors`}
                        disabled={!!editingElement}
                    >
                        Inspection Form
                    </button>
                    <button
                        onClick={() => { setEditingElement(null); setCurrentView('report'); }}
                        className={`${
                            currentView === 'report' && !editingElement
                            ? 'border-brand-orange text-brand-blue'
                            : 'border-transparent text-gray-500 hover:text-brand-blue hover:border-gray-300'
                        } whitespace-nowrap py-4 px-1 border-b-4 font-medium text-sm transition-colors`}
                        disabled={!!editingElement}
                    >
                        Report View
                    </button>
                </nav>
            </div>
            <div style={{ display: currentView === 'wizard' ? 'block' : 'none' }}>
              <InspectionWizard 
                inspectionApi={inspectionApi} 
                onNavigateToElement={handleNavigateToElement}
                onAddElement={handleAddElement}
              />
            </div>
            {currentView === 'report' && <ReportView inspection={inspectionApi.inspection} />}
         </>
      );
  }

  return (
    <div className="min-h-screen font-sans text-brand-gray-800">
      <Header resetInspection={inspectionApi.resetInspection} />
      <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {renderContent()}
      </main>
      {currentView !== 'landing' && (
          <footer className="text-center p-4 text-sm text-brand-gray-500">
             <ProexpertLogo className="h-10 mx-auto mb-2" />
             www.proexpert.com | contact@proexpert.com | +123 456 7890
          </footer>
      )}
    </div>
  );
};

export default App;