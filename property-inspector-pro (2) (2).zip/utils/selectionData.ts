export const PREDEFINED_FLOORS: string[] = [
    'Ground Floor',
    'First Floor',
    'Second Floor',
    'Third Floor',
    'Terrace',
];

export const PREDEFINED_ROOMS: string[] = [
    'Bedroom',
    'Living Room',
    'Kitchen',
    'Bathroom',
    'Balcony',
    'Utility',
];
