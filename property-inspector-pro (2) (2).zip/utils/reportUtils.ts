import { Inspection, Floor, Room, InspectionElement, WorkStatus } from '../types';
import { getRoomIconData, getElementIconData, getLogoData } from './iconUtils';

const escapeCsvCell = (cell: string | string[]): string => {
  const cellString = Array.isArray(cell) ? cell.join('; ') : cell;
  let escaped = cellString.replace(/"/g, '""');
  if (escaped.includes(',') || escaped.includes('\n') || escaped.includes('"')) {
    escaped = `"${escaped}"`;
  }
  return escaped;
};

export const generateCsv = (inspection: Inspection): void => {
  const headers = [
    'Project Name',
    'Inspector',
    'Date',
    'Floor',
    'Room',
    'Element Type',
    'Work Status',
    'Problems',
    'Notes',
    'Photo Count'
  ];

  let csvContent = headers.join(',') + '\n';

  inspection.floors.forEach((floor: Floor) => {
    floor.rooms.forEach((room: Room) => {
      room.elements.forEach((element: InspectionElement) => {
        const row = [
          inspection.projectName,
          inspection.inspector,
          inspection.date,
          floor.name,
          room.name,
          element.elementType,
          element.workStatus,
          element.problems,
          element.notes,
          element.photos.length.toString(),
        ].map(escapeCsvCell);
        csvContent += row.join(',') + '\n';
      });
    });
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    const filename = `inspection-report-${inspection.projectName.replace(/\s+/g, '-')}-${inspection.date}.csv`;
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

declare var jspdf: any;

export const generatePdf = (inspection: Inspection) => {
    const { jsPDF } = jspdf;
    const pdf = new jsPDF({ orientation: 'p', unit: 'pt', format: 'a4' });

    const COLOR_PRIMARY = '#004AAD';
    const COLOR_SECONDARY = '#F6A31A';
    const COLOR_TEXT_LIGHT = '#FFFFFF';
    const COLOR_TEXT_DARK = '#374151';
    const COLOR_BACKGROUND_ACCENT = '#F5F5F5';
    const COLOR_STATUS_OK = '#10B981';
    const COLOR_STATUS_ATTENTION = '#F59E0B';
    const COLOR_STATUS_ISSUE = '#EF4444';

    const MARGIN = 40;
    const PAGE_WIDTH = pdf.internal.pageSize.getWidth();
    const PAGE_HEIGHT = pdf.internal.pageSize.getHeight();
    const CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2;
    const FOOTER_HEIGHT = 40;
    const PAGE_BREAK_THRESHOLD = PAGE_HEIGHT - MARGIN - FOOTER_HEIGHT;

    let y = 0;

    const addFooter = (pageNumber: number, totalPages: number) => {
      pdf.setFontSize(8);
      pdf.setTextColor(COLOR_TEXT_DARK);
      
      const logoData = getLogoData();
      if(logoData) {
        pdf.addImage(logoData, 'SVG', MARGIN, PAGE_HEIGHT - FOOTER_HEIGHT + 5, 100, 25);
      }

      const contactText = 'www.proexpert.com | contact@proexpert.com';
      pdf.setFont('helvetica', 'normal');
      pdf.text(contactText, PAGE_WIDTH / 2, PAGE_HEIGHT - FOOTER_HEIGHT + 17, { align: 'center' });

      pdf.text(`Page ${pageNumber} of ${totalPages}`, PAGE_WIDTH - MARGIN, PAGE_HEIGHT - FOOTER_HEIGHT + 17, { align: 'right' });
    };

    const addPageWithFooter = () => {
        pdf.addPage();
        y = MARGIN;
    };
    
    const addWrappedText = (text: string, x: number, currentY: number, maxWidth: number, lineHeight: number, isBold = false) => {
        if (isBold) pdf.setFont('helvetica', 'bold');
        const lines = pdf.splitTextToSize(text, maxWidth);
        lines.forEach((line: string) => {
            if (currentY > PAGE_BREAK_THRESHOLD) {
                addPageWithFooter();
                currentY = MARGIN;
            }
            pdf.text(line, x, currentY);
            currentY += lineHeight;
        });
        if (isBold) pdf.setFont('helvetica', 'normal');
        return currentY;
    };
    
    // Cover Page
    pdf.setFillColor(COLOR_PRIMARY);
    pdf.rect(0, 0, PAGE_WIDTH, 120, 'F');
    y = 120;
    
    const logoData = getLogoData();
    if(logoData) {
      pdf.addImage(logoData, 'SVG', PAGE_WIDTH / 2 - 125, MARGIN, 250, 60);
    }
    y += 80;

    pdf.setFontSize(28);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(COLOR_PRIMARY);
    pdf.text('Property Inspection Report', PAGE_WIDTH / 2, y, { align: 'center' });
    y += 40;

    pdf.setFontSize(18);
    pdf.setTextColor(COLOR_TEXT_DARK);
    pdf.text(inspection.projectName, PAGE_WIDTH / 2, y, { align: 'center' });
    y += 80;
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    
    const details = [
        { label: 'Client Name', value: inspection.clientName },
        { label: 'Property Address', value: inspection.address },
        { label: 'Unit Details', value: `${inspection.blockPhase || ''} - ${inspection.unitNumber || ''}`.replace(/^-| - $/, '')},
        { label: 'Inspector Name', value: inspection.inspector },
        { label: 'Inspection Date', value: inspection.date },
    ];
    
    details.forEach(detail => {
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(COLOR_PRIMARY);
        pdf.text(`${detail.label}:`, MARGIN + 10, y);
        
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(COLOR_TEXT_DARK);
        addWrappedText(detail.value || 'N/A', MARGIN + 130, y, CONTENT_WIDTH - 140, 14);
        y += 25;
        
        pdf.setDrawColor(COLOR_BACKGROUND_ACCENT);
        pdf.setLineWidth(1);
        pdf.line(MARGIN, y, PAGE_WIDTH - MARGIN, y);
        y += 20;
    });

    addPageWithFooter();

    // Main Content
    inspection.floors.forEach(floor => {
        y += 20;
        if (y > PAGE_BREAK_THRESHOLD - 50) addPageWithFooter();
        
        pdf.setFillColor(COLOR_PRIMARY);
        pdf.rect(MARGIN, y, CONTENT_WIDTH, 30, 'F');
        pdf.setFontSize(18);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(COLOR_TEXT_LIGHT);
        pdf.text(floor.name, MARGIN + 10, y + 20);
        y += 45;

        floor.rooms.forEach(room => {
            if (room.elements.length === 0) return;
            if (y > PAGE_BREAK_THRESHOLD - 40) addPageWithFooter();
            
            const roomIcon = getRoomIconData(room.name);
            const iconSize = 16;
            
            pdf.setFillColor(COLOR_BACKGROUND_ACCENT);
            pdf.rect(MARGIN, y - 15, CONTENT_WIDTH, 24, 'F');
            
            let textX = MARGIN + 10;
            if (roomIcon) {
                try {
                    pdf.addImage(roomIcon, 'SVG', MARGIN + 5, y - 12, iconSize, iconSize);
                    textX += iconSize + 5;
                } catch(e) { console.error("PDF addImage error:", e); }
            }

            pdf.setFontSize(14);
            pdf.setFont('helvetica', 'bold');
            pdf.setTextColor(COLOR_TEXT_DARK);
            pdf.text(room.name, textX, y);
            y += 30;

            room.elements.forEach(element => {
                if (y > PAGE_BREAK_THRESHOLD - 80) addPageWithFooter();

                const elementIcon = getElementIconData(element.elementType);
                const elIconSize = 14;
                let elTextX = MARGIN + 5;
                 if (elementIcon) {
                    try {
                        pdf.addImage(elementIcon, 'SVG', MARGIN + 5, y - elIconSize + 2, elIconSize, elIconSize);
                        elTextX += elIconSize + 5;
                    } catch(e) { console.error("PDF addImage error:", e); }
                }

                pdf.setFontSize(12);
                pdf.setFont('helvetica', 'bold');
                pdf.setTextColor(COLOR_PRIMARY);
                pdf.text(element.elementType, elTextX, y);

                // Status bubble
                const statusColor = {
                  [WorkStatus.Completed]: COLOR_STATUS_OK,
                  [WorkStatus.Attention]: COLOR_STATUS_ATTENTION,
                  [WorkStatus.Issue]: COLOR_STATUS_ISSUE,
                }[element.workStatus];
                pdf.setFontSize(9);
                pdf.setFont('helvetica', 'bold');
                pdf.setTextColor(statusColor);
                const statusText = element.workStatus.toUpperCase();
                const statusWidth = pdf.getStringUnitWidth(statusText) * 9;
                pdf.text(statusText, PAGE_WIDTH - MARGIN - statusWidth, y);
                y += 20;

                pdf.setFontSize(10);
                pdf.setFont('helvetica', 'normal');
                pdf.setTextColor(COLOR_TEXT_DARK);
                
                const elementDetails = [
                    {label: 'Problems:', value: element.problems.join(', ')},
                    {label: 'Remarks:', value: element.notes}
                ];

                elementDetails.forEach(detail => {
                    if(detail.value) {
                         if (y > PAGE_BREAK_THRESHOLD) addPageWithFooter();
                        pdf.setFont('helvetica', 'bold');
                        pdf.text(detail.label, MARGIN + 10, y);
                        pdf.setFont('helvetica', 'normal');
                        y = addWrappedText(detail.value, MARGIN + 80, y, CONTENT_WIDTH - 90, 12);
                    }
                });

                if (element.photos.length > 0) {
                    y += 10;
                    if (y > PAGE_BREAK_THRESHOLD) addPageWithFooter();
                    pdf.setFont('helvetica', 'bold');
                    pdf.text('Photos:', MARGIN + 10, y);
                    y += 15;

                    const photoSize = 120;
                    const gap = 10;
                    let x = MARGIN + 10;
                    element.photos.forEach(photo => {
                        if (x + photoSize > PAGE_WIDTH - MARGIN) {
                            x = MARGIN + 10;
                            y += photoSize + gap;
                        }
                        if (y + photoSize > PAGE_BREAK_THRESHOLD) {
                            addPageWithFooter();
                            x = MARGIN + 10;
                        }

                        try {
                            pdf.addImage(photo.dataUrl, 'JPEG', x, y, photoSize, photoSize);
                            if (photo.markings) {
                                pdf.addImage(photo.markings, 'PNG', x, y, photoSize, photoSize);
                            }
                        } catch (e) {
                            console.error("Error adding image to PDF:", e);
                            pdf.text('Image Error', x + 10, y + photoSize / 2);
                        }
                        x += photoSize + gap;
                    });
                    y += photoSize + 20;
                }
                y += 15;
            });
        });
    });

    const pageCount = pdf.internal.getNumberOfPages();
    for(let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        addFooter(i, pageCount);
    }

    return pdf;
};