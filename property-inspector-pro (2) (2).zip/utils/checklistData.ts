import { ElementType, WorkStatus } from "../types";

export const WORK_STATUSES: WorkStatus[] = [
    WorkStatus.Attention,
    WorkStatus.Completed,
    WorkStatus.Issue,
];

export const ELEMENT_TYPES: ElementType[] = [
    ElementType.Wall,
    ElementType.Ceiling,
    ElementType.Floor,
    ElementType.Door,
    ElementType.Window,
    ElementType.Electrical,
    ElementType.Plumbing,
    ElementType.Fixtures,
];

export const ELEMENT_CHECKLISTS: Record<ElementType, string[]> = {
    [ElementType.Wall]: ['Crack', 'Seepage', 'Dampness', 'Paint Peeling', 'Hollow Sound', 'Uneven Surface'],
    [ElementType.Ceiling]: ['Leakage', 'Crack', 'Seepage Stain', 'Paint Peeling', 'Uneven Surface'],
    [ElementType.Floor]: ['Cracked Tile', 'Chipped Tile', 'Hollow Tile', 'Uneven Grouting', 'Stain'],
    [ElementType.Door]: ['Alignment Issue', 'Lock Issue', 'Gap', 'Scratch/Dent', 'Hinge Noise'],
    [ElementType.Window]: ['Alignment Issue', 'Lock Issue', 'Glass Crack', 'Gap', 'Water Seepage'],
    [ElementType.Electrical]: ['Switch not working', 'Socket not working', 'Loose Fitting', 'Incorrect Wiring'],
    [ElementType.Plumbing]: ['Leakage', 'Low Water Pressure', 'Blockage', 'Rust', 'Improper Installation'],
    [ElementType.Fixtures]: ['Loose', 'Broken', 'Leaking', 'Not Working', 'Scratched/Dented'],
};