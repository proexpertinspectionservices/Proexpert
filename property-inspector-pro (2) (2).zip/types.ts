// Fix: Add comprehensive type definitions for the nested inspection data structure.
export enum WorkStatus {
  Completed = 'Completed',
  Attention = 'Attention',
  Issue = 'Issue',
}

export enum ElementType {
  Wall = 'Wall',
  Ceiling = 'Ceiling',
  Floor = 'Floor',
  Door = 'Door',
  Window = 'Window',
  Electrical = 'Electrical',
  Plumbing = 'Plumbing',
  Fixtures = 'Fixtures',
}

export interface Photo {
  id: string;
  name: string;
  dataUrl: string;
  markings?: string;
}

export interface InspectionElement {
  id:string;
  elementType: ElementType;
  workStatus: WorkStatus;
  problems: string[];
  notes: string;
  photos: Photo[];
}

export interface Room {
  id: string;
  name: string;
  elements: InspectionElement[];
}

export interface Floor {
  id: string;
  name: string;
  rooms: Room[];
}

export interface Inspection {
  projectName: string;
  inspector: string;
  date: string;
  address: string;
  blockPhase: string;
  unitNumber: string;
  clientName: string;
  floors: Floor[];
}